import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator, FileSpreadsheet, FileText, Download } from 'lucide-react';
import useSettingsStore from '../store/settingsStore';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

export default function QuoteGenerator() {
  const { activities } = useSettingsStore();
  const [selectedActivities, setSelectedActivities] = useState<string[]>([]);
  const [quantity, setQuantity] = useState<{ [key: string]: number }>({});
  const [companyName, setCompanyName] = useState('');
  const [contactName, setContactName] = useState('');

  const totalPrice = selectedActivities.reduce((total, activityId) => {
    const activity = activities.find((a) => a.id === activityId);
    return total + (activity?.price || 0) * (quantity[activityId] || 1);
  }, 0);

  const handleActivityToggle = (activityId: string) => {
    setSelectedActivities((prev) =>
      prev.includes(activityId)
        ? prev.filter((id) => id !== activityId)
        : [...prev, activityId]
    );
  };

  const handleQuantityChange = (activityId: string, value: number) => {
    setQuantity((prev) => ({
      ...prev,
      [activityId]: value,
    }));
  };

  const getQuoteData = () => {
    return selectedActivities.map((activityId) => {
      const activity = activities.find((a) => a.id === activityId);
      const activityQuantity = quantity[activityId] || 1;
      return {
        Activity: activity?.name,
        Quantity: activityQuantity,
        'Unit Price': `$${activity?.price}`,
        Total: `$${(activity?.price || 0) * activityQuantity}`,
      };
    });
  };

  const exportToExcel = () => {
    const data = getQuoteData();
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Quote');
    
    // Add summary information
    XLSX.utils.sheet_add_aoa(ws, [
      ['Quote Summary'],
      ['Company:', companyName],
      ['Contact:', contactName],
      ['Total:', `$${totalPrice}`],
    ], { origin: -1 });

    XLSX.writeFile(wb, `quote-${Date.now()}.xlsx`);
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    
    // Add header
    doc.setFontSize(20);
    doc.text('Quote', 14, 15);
    
    // Add company info
    doc.setFontSize(12);
    doc.text(`Company: ${companyName}`, 14, 25);
    doc.text(`Contact: ${contactName}`, 14, 32);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 14, 39);

    // Add table
    autoTable(doc, {
      head: [['Activity', 'Quantity', 'Unit Price', 'Total']],
      body: getQuoteData().map(row => [
        row.Activity,
        row.Quantity,
        row['Unit Price'],
        row.Total,
      ]),
      startY: 45,
    });

    // Add total
    const finalY = (doc as any).lastAutoTable.finalY || 45;
    doc.text(`Total: $${totalPrice.toLocaleString()}`, 14, finalY + 10);

    doc.save(`quote-${Date.now()}.pdf`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Quote Generator</h1>
        <p className="text-gray-500">Generate quotes based on selected activities</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Company Information</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company Name
                </label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contact Name
                </label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Select Activities</h2>
            <div className="space-y-4">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between">
                  <label className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={selectedActivities.includes(activity.id)}
                      onChange={() => handleActivityToggle(activity.id)}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <span className="text-gray-900">{activity.name}</span>
                    <span className="text-sm text-gray-500">${activity.price}</span>
                  </label>
                  {selectedActivities.includes(activity.id) && (
                    <input
                      type="number"
                      min="1"
                      value={quantity[activity.id] || 1}
                      onChange={(e) =>
                        handleQuantityChange(activity.id, parseInt(e.target.value) || 1)
                      }
                      className="w-20 px-2 py-1 border border-gray-200 rounded-lg text-right"
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <motion.div
          initial={false}
          animate={{
            scale: selectedActivities.length > 0 ? 1 : 0.95,
            opacity: selectedActivities.length > 0 ? 1 : 0.5,
          }}
          className="space-y-6"
        >
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Quote Summary</h2>
            {selectedActivities.length > 0 ? (
              <div className="space-y-4">
                {selectedActivities.map((activityId) => {
                  const activity = activities.find((a) => a.id === activityId);
                  if (!activity) return null;
                  const activityQuantity = quantity[activityId] || 1;
                  return (
                    <div key={activity.id} className="flex justify-between text-sm">
                      <span className="text-gray-600">
                        {activity.name} x {activityQuantity}
                      </span>
                      <span className="text-gray-900">
                        ${(activity.price * activityQuantity).toLocaleString()}
                      </span>
                    </div>
                  );
                })}
                <div className="pt-4 border-t border-gray-100">
                  <div className="flex justify-between font-semibold">
                    <span className="text-gray-900">Total</span>
                    <span className="text-blue-600">${totalPrice.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-40 text-gray-400">
                <Calculator className="w-8 h-8 mb-2" />
                <p>Select activities to generate a quote</p>
              </div>
            )}
          </div>

          {selectedActivities.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Export Quote</h2>
              <div className="flex gap-4">
                <button
                  onClick={exportToExcel}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <FileSpreadsheet className="w-5 h-5" />
                  <span>Excel</span>
                </button>
                <button
                  onClick={exportToPDF}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <FileText className="w-5 h-5" />
                  <span>PDF</span>
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}