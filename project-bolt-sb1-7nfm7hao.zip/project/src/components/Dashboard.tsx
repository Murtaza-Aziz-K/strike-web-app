import React from 'react';
import { Activity, Users, MessageSquare, FileText } from 'lucide-react';

const stats = [
  {
    label: 'Total Interactions',
    value: '2,847',
    change: '+12.5%',
    icon: Activity,
  },
  {
    label: 'Active Users',
    value: '42',
    change: '+4.3%',
    icon: Users,
  },
  {
    label: 'AI Conversations',
    value: '1,234',
    change: '+18.2%',
    icon: MessageSquare,
  },
  {
    label: 'Documents Processed',
    value: '386',
    change: '+7.1%',
    icon: FileText,
  },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500">Welcome to Strike AI platform</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const isPositive = stat.change.startsWith('+');
          
          return (
            <div
              key={stat.label}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <Icon className="w-5 h-5 text-blue-600" />
                <span className={`text-sm font-medium ${
                  isPositive ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.change}
                </span>
              </div>
              <div className="mt-4">
                <h3 className="text-sm font-medium text-gray-500">{stat.label}</h3>
                <p className="text-2xl font-semibold text-gray-900 mt-1">{stat.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-2 h-2 rounded-full bg-blue-600" />
              <div>
                <p className="text-sm text-gray-900">New AI conversation started</p>
                <p className="text-xs text-gray-500">2 minutes ago</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-2 h-2 rounded-full bg-green-600" />
              <div>
                <p className="text-sm text-gray-900">Document processed successfully</p>
                <p className="text-xs text-gray-500">15 minutes ago</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-2 h-2 rounded-full bg-purple-600" />
              <div>
                <p className="text-sm text-gray-900">System report generated</p>
                <p className="text-xs text-gray-500">1 hour ago</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">System Overview</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">API Usage</span>
              <div className="w-48 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="w-3/4 h-full bg-blue-600 rounded-full" />
              </div>
              <span className="text-sm font-medium text-gray-900">75%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Storage</span>
              <div className="w-48 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="w-1/2 h-full bg-blue-600 rounded-full" />
              </div>
              <span className="text-sm font-medium text-gray-900">50%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Processing</span>
              <div className="w-48 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="w-4/5 h-full bg-blue-600 rounded-full" />
              </div>
              <span className="text-sm font-medium text-gray-900">80%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}