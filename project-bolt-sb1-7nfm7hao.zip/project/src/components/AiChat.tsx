import React, { useState, useRef, useEffect } from 'react';
import { Send, Upload, Loader2, Bot, User, Image, FileText, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import clsx from 'clsx';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export default function AiChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input.trim(),
      role: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const completion = await openai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are Strike AI, a retail analytics assistant. You help with analyzing retail data, generating insights, and providing recommendations. Be concise, professional, and focus on retail-specific insights.'
          },
          ...messages.map(msg => ({
            role: msg.role as 'user' | 'assistant',
            content: msg.content
          })),
          { role: 'user', content: input.trim() }
        ],
        model: 'gpt-3.5-turbo',
      });

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: completion.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "I apologize, but I encountered an error. Please check your API key configuration and try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const userMessage: Message = {
        id: Date.now().toString(),
        content: `Uploaded file: ${file.name}`,
        role: 'user',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, userMessage]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      const userMessage: Message = {
        id: Date.now().toString(),
        content: `Dropped file: ${file.name}`,
        role: 'user',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, userMessage]);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="bg-white rounded-t-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Strike AI Assistant</h1>
            <p className="text-gray-500 mt-1">
              Your intelligent retail analytics companion
            </p>
          </div>
        </div>
      </div>

      <div 
        className={clsx(
          "flex-1 bg-gray-50 overflow-y-auto p-6 space-y-6",
          isDragging && "bg-blue-50"
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-gray-400 space-y-4">
            <div className="grid grid-cols-2 gap-4 max-w-2xl w-full">
              <div className="col-span-2">
                <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                  <Bot className="w-6 h-6 text-blue-600 mb-2" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Welcome to Strike AI
                  </h3>
                  <p className="text-gray-500">
                    I'm your AI assistant for retail analytics and insights. How can I help you today?
                  </p>
                </div>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <Image className="w-6 h-6 text-blue-600 mb-2" />
                <h3 className="text-sm font-semibold text-gray-900 mb-2">
                  Analyze Images
                </h3>
                <p className="text-sm text-gray-500">
                  Upload images for retail analysis and insights
                </p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <FileText className="w-6 h-6 text-blue-600 mb-2" />
                <h3 className="text-sm font-semibold text-gray-900 mb-2">
                  Process Documents
                </h3>
                <p className="text-sm text-gray-500">
                  Extract insights from retail documents
                </p>
              </div>
            </div>
          </div>
        )}
        
        <AnimatePresence initial={false}>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`flex items-start gap-3 ${
                message.role === 'assistant' ? 'flex-row' : 'flex-row-reverse'
              }`}
            >
              <div
                className={clsx(
                  "w-10 h-10 rounded-lg flex items-center justify-center",
                  message.role === 'assistant' ? 'bg-blue-100' : 'bg-gray-100'
                )}
              >
                {message.role === 'assistant' ? (
                  <Bot className="w-6 h-6 text-blue-600" />
                ) : (
                  <User className="w-6 h-6 text-gray-600" />
                )}
              </div>
              <div
                className={clsx(
                  "flex-1 rounded-2xl px-6 py-4",
                  message.role === 'assistant'
                    ? 'bg-white border border-gray-100 shadow-sm'
                    : 'bg-blue-600 text-white'
                )}
              >
                <p className={message.role === 'assistant' ? 'text-gray-900' : 'text-white'}>
                  {message.content}
                </p>
                <p
                  className={clsx(
                    "text-xs mt-2",
                    message.role === 'assistant' ? 'text-gray-400' : 'text-blue-100'
                  )}
                >
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Bot className="w-6 h-6 text-blue-600" />
              </div>
              <div className="bg-white rounded-2xl px-6 py-4 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                  <span className="text-gray-500">Thinking...</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      <div className="bg-white rounded-b-xl shadow-sm border border-gray-100 p-6">
        <form onSubmit={handleSubmit} className="flex gap-4">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-3 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <Upload className="w-5 h-5" />
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
            accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
          />
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Message Strike AI..."
            className="flex-1 bg-gray-50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="p-3 text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}