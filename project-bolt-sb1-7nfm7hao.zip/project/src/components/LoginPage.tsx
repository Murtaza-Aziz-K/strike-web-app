import React, { useState } from 'react';
import { motion } from 'framer-motion';
import useAuthStore from '../store/authStore';
import { Logo } from './Logo';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const login = useAuthStore(state => state.login);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(username, password);
    } catch (err) {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Main Background */}
      <div 
        className="fixed inset-0"
        style={{
          animation: 'backgroundShift 10s ease-in-out infinite',
        }}
      />

      {/* Animated Grid Pattern */}
      <div 
        className="fixed inset-0 opacity-[0.07]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '100px 100px',
          animation: 'moveGrid 15s linear infinite',
        }}
      />

      {/* Pulsing Circles */}
      <div className="fixed inset-0 flex items-center justify-center">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-[800px] h-[800px] rounded-full"
            style={{
              background: `radial-gradient(circle at center, rgba(56, 189, 248, ${0.15 - i * 0.03}) 0%, transparent 70%)`,
              filter: 'blur(60px)',
              animation: `pulse 8s ease-in-out infinite ${i * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Login Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div 
          className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] p-8 rounded-2xl shadow-[0_0_50px_0_rgba(0,0,0,0.3)] border border-sky-500/20"
          style={{ 
            animation: 'glow 3s ease-in-out infinite',
            boxShadow: '0 0 50px rgba(0, 0, 0, 0.5), inset 0 0 30px rgba(56, 189, 248, 0.2)'
          }}
        >
          <motion.div 
            className="flex items-center justify-center mb-8"
            animate={{ 
              scale: [1, 1.02, 1],
              rotate: [0, 2, -2, 0]
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <div className="bg-gradient-to-br from-sky-400 to-sky-500 p-3 rounded-xl shadow-lg">
              <Logo className="w-8 h-8 text-white" />
            </div>
          </motion.div>
          
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2 text-shadow">Strike AI</h1>
            <p className="text-sky-200/80">
              Intelligent Utility Platform
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-red-500/10 text-red-400 p-4 rounded-lg text-sm border border-red-500/20"
              >
                {error}
              </motion.div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-sky-200/80 mb-2">
                Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 bg-slate-800/50 border border-sky-500/20 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent text-white placeholder-sky-200/30 transition-all hover:bg-slate-800/70"
                placeholder="Enter your username"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-sky-200/80 mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-slate-800/50 border border-sky-500/20 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent text-white placeholder-sky-200/30 transition-all hover:bg-slate-800/70"
                placeholder="Enter your password"
              />
            </div>

            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full bg-gradient-to-r from-sky-400 to-sky-500 text-white py-3 px-4 rounded-lg hover:from-sky-300 hover:to-sky-400 transition-all duration-200 flex items-center justify-center gap-2 font-medium shadow-lg"
            >
              <span>Sign In</span>
              <Logo className="w-5 h-5 text-white" />
            </motion.button>
          </form>

          <p className="text-center text-sm text-sky-200/80 mt-8">
            Powered by Strike AI Technology
          </p>
        </div>
      </motion.div>
    </div>
  );
}