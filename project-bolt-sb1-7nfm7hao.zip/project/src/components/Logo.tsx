import React from 'react';

export function Logo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      className={className} 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <path 
        d="M13 2L4 13h7l-2 7 9-11h-7l2-7z" 
        className="fill-current"
        style={{
          filter: "drop-shadow(0 1px 2px rgb(0 0 0 / 0.1))"
        }}
      />
    </svg>
  );
}