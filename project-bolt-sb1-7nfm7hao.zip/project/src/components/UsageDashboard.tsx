import React from 'react';
import { motion } from 'framer-motion';
import {
  BarChart3,
  Users,
  MessageSquare,
  FileText,
  TrendingUp,
  Clock,
} from 'lucide-react';

const metrics = [
  {
    label: 'Total Users',
    value: '156',
    change: '+12.5%',
    icon: Users,
  },
  {
    label: 'AI Conversations',
    value: '2,847',
    change: '+18.2%',
    icon: MessageSquare,
  },
  {
    label: 'Quotes Generated',
    value: '386',
    change: '+7.1%',
    icon: FileText,
  },
  {
    label: 'Revenue Generated',
    value: '$125,400',
    change: '+22.4%',
    icon: TrendingUp,
  },
];

const timelineData = [
  {
    time: '09:00 AM',
    event: 'New AI conversation started by John Doe',
    type: 'conversation',
  },
  {
    time: '10:15 AM',
    event: 'Quote generated for XYZ Corp',
    type: 'quote',
  },
  {
    time: '11:30 AM',
    event: 'Revenue report exported by Admin',
    type: 'report',
  },
  {
    time: '02:45 PM',
    event: 'New lead added in FMCG department',
    type: 'lead',
  },
];

export default function UsageDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Usage Dashboard</h1>
        <p className="text-gray-500">Monitor system usage and performance metrics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-6"
            >
              <div className="flex items-center justify-between">
                <Icon className="w-5 h-5 text-blue-600" />
                <span className="text-sm font-medium text-green-600">{metric.change}</span>
              </div>
              <div className="mt-4">
                <h3 className="text-sm font-medium text-gray-500">{metric.label}</h3>
                <p className="text-2xl font-semibold text-gray-900 mt-1">{metric.value}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Usage Timeline</h2>
          <div className="space-y-6">
            {timelineData.map((item, index) => (
              <div key={index} className="flex gap-4">
                <div className="flex-none">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <Clock className="w-4 h-4 text-blue-600" />
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-900">{item.event}</p>
                  <p className="text-xs text-gray-500 mt-1">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Department Activity</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">FMCG</span>
                <span className="text-gray-900">75%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 rounded-full" style={{ width: '75%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">C&I</span>
                <span className="text-gray-900">60%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 rounded-full" style={{ width: '60%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">VRP</span>
                <span className="text-gray-900">85%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 rounded-full" style={{ width: '85%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">DIY</span>
                <span className="text-gray-900">45%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 rounded-full" style={{ width: '45%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}