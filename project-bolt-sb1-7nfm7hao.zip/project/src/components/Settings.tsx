import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Save, AlertCircle, Mail, UserPlus } from 'lucide-react';
import useSettingsStore from '../store/settingsStore';
import useUserManagementStore from '../store/userManagementStore';

export default function Settings() {
  const { activities, addActivity, updateActivity, deleteActivity } = useSettingsStore();
  const { roles, addRole, updateRole, deleteRole } = useUserManagementStore();
  
  const [newActivity, setNewActivity] = useState({ name: '', price: 0 });
  const [newRole, setNewRole] = useState({ 
    name: '', 
    permissions: {
      dashboard: true,
      ai: true,
      revenue: true,
      quotes: true,
      usage: true,
      settings: false
    }
  });
  const [invitation, setInvitation] = useState({
    email: '',
    role: '',
    departments: [] as string[],
  });
  const [invitationStatus, setInvitationStatus] = useState<{
    type: 'success' | 'error' | null;
    message: string;
  }>({ type: null, message: '' });

  const departments = ['FMCG', 'C&I', 'VRP', 'Extravert', 'DIY'];

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (newActivity.name && newActivity.price > 0) {
      addActivity(newActivity);
      setNewActivity({ name: '', price: 0 });
    }
  };

  const handleAddRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (newRole.name) {
      addRole(newRole);
      setNewRole({ 
        name: '', 
        permissions: {
          dashboard: true,
          ai: true,
          revenue: true,
          quotes: true,
          usage: true,
          settings: false
        }
      });
    }
  };

  const handleInviteUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!invitation.email || !invitation.role) {
      setInvitationStatus({
        type: 'error',
        message: 'Please fill in all required fields'
      });
      return;
    }

    // Simulate sending invitation
    setInvitationStatus({
      type: 'success',
      message: `Invitation sent to ${invitation.email}`
    });
    setInvitation({
      email: '',
      role: '',
      departments: [],
    });

    // Clear status after 3 seconds
    setTimeout(() => {
      setInvitationStatus({ type: null, message: '' });
    }, 3000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500">Manage activities, user roles, and invitations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Activities Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Activities</h2>
          
          <form onSubmit={handleAddActivity} className="flex gap-4 mb-6">
            <input
              type="text"
              value={newActivity.name}
              onChange={(e) => setNewActivity({ ...newActivity, name: e.target.value })}
              placeholder="Activity name"
              className="flex-1 px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <input
              type="number"
              value={newActivity.price}
              onChange={(e) => setNewActivity({ ...newActivity, price: Number(e.target.value) })}
              placeholder="Price"
              min="0"
              className="w-32 px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </form>

          <div className="space-y-3">
            {activities.map((activity) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <span className="text-gray-900">{activity.name}</span>
                <div className="flex items-center gap-4">
                  <span className="text-gray-600">${activity.price}</span>
                  <button
                    onClick={() => deleteActivity(activity.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Roles Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">User Roles</h2>
          
          <form onSubmit={handleAddRole} className="mb-6">
            <div className="flex gap-4 mb-4">
              <input
                type="text"
                value={newRole.name}
                onChange={(e) => setNewRole({ ...newRole, name: e.target.value })}
                placeholder="Role name"
                className="flex-1 px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
          </form>

          <div className="space-y-4">
            {roles.map((role) => (
              <motion.div
                key={role.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-gray-50 rounded-lg space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900">{role.name}</span>
                  {role.id !== 'admin' && (
                    <button
                      onClick={() => deleteRole(role.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(role.permissions).map(([key, value]) => (
                    <label
                      key={key}
                      className="flex items-center gap-2 text-sm"
                    >
                      <input
                        type="checkbox"
                        checked={value}
                        onChange={(e) => {
                          if (role.id !== 'admin') {
                            updateRole(role.id, {
                              permissions: {
                                ...role.permissions,
                                [key]: e.target.checked
                              }
                            });
                          }
                        }}
                        disabled={role.id === 'admin'}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                      />
                      <span className="capitalize">{key}</span>
                    </label>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* User Invitations Section */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Invite Users</h2>
          
          <form onSubmit={handleInviteUser} className="space-y-6">
            {invitationStatus.type && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 rounded-lg ${
                  invitationStatus.type === 'success' 
                    ? 'bg-green-50 text-green-700' 
                    : 'bg-red-50 text-red-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  {invitationStatus.type === 'success' ? (
                    <Mail className="w-5 h-5" />
                  ) : (
                    <AlertCircle className="w-5 h-5" />
                  )}
                  <p>{invitationStatus.message}</p>
                </div>
              </motion.div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={invitation.email}
                  onChange={(e) => setInvitation({ ...invitation, email: e.target.value })}
                  placeholder="user@example.com"
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Role
                </label>
                <select
                  value={invitation.role}
                  onChange={(e) => setInvitation({ ...invitation, role: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select a role</option>
                  {roles.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Departments
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {departments.map((dept) => (
                  <label key={dept} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={invitation.departments.includes(dept)}
                      onChange={(e) => {
                        setInvitation({
                          ...invitation,
                          departments: e.target.checked
                            ? [...invitation.departments, dept]
                            : invitation.departments.filter((d) => d !== dept),
                        });
                      }}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-700">{dept}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <UserPlus className="w-5 h-5" />
                Send Invitation
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}