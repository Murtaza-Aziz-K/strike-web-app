import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Brain, 
  LineChart, 
  FileText, 
  LayoutDashboard, 
  Settings,
  LogOut,
  BarChart,
  Sparkles
} from 'lucide-react';
import useAuthStore from '../store/authStore';
import useUserManagementStore from '../store/userManagementStore';
import { motion } from 'framer-motion';

const navItems = [
  { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard', permission: 'dashboard' },
  { path: '/ai', icon: Brain, label: 'Strike AI', permission: 'ai' },
  { path: '/revenue', icon: LineChart, label: 'Revenue Tracker', permission: 'revenue' },
  { path: '/quotes', icon: FileText, label: 'Quote Generator', permission: 'quotes' },
  { path: '/usage', icon: BarChart, label: 'Usage Dashboard', permission: 'usage' },
  { path: '/settings', icon: Settings, label: 'Settings', permission: 'settings' },
];

export default function Navbar() {
  const location = useLocation();
  const logout = useAuthStore(state => state.logout);
  const user = useAuthStore(state => state.user);
  const roles = useUserManagementStore(state => state.roles);

  const userRole = user?.role ? roles.find(role => role.id === user.role) : null;

  const filteredNavItems = navItems.filter(item => {
    return userRole?.permissions?.[item.permission as keyof typeof userRole.permissions];
  });

  return (
    <nav className="fixed top-0 left-0 h-screen w-64 bg-white border-r border-gray-200 p-6 flex flex-col">
      <div className="flex items-center gap-3 px-2 mb-8">
        <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
          <Sparkles className="w-6 h-6 text-blue-600" />
        </div>
        <span className="text-xl font-bold text-gray-900">Strike AI</span>
      </div>

      <div className="flex-1 space-y-2">
        {filteredNavItems.map(({ path, icon: Icon, label }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all relative group"
            >
              {isActive && (
                <motion.div
                  layoutId="activeNav"
                  className="absolute inset-0 bg-blue-50 rounded-xl"
                  initial={false}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              )}
              <Icon className={`w-5 h-5 relative ${
                isActive ? 'text-blue-600' : 'text-gray-400 group-hover:text-blue-600'
              }`} />
              <span className={`relative ${
                isActive ? 'text-blue-600' : 'text-gray-600 group-hover:text-blue-600'
              }`}>
                {label}
              </span>
            </Link>
          );
        })}
      </div>

      <div className="border-t border-gray-200 pt-4">
        {user && (
          <div className="px-4 py-3 mb-4">
            <div className="text-sm font-medium text-gray-900">{user.username}</div>
            <div className="text-xs text-gray-500 capitalize">{userRole?.name || user.role}</div>
          </div>
        )}
        <button
          onClick={logout}
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 w-full transition-all group"
        >
          <LogOut className="w-5 h-5 group-hover:rotate-180 transition-transform duration-300" />
          <span>Logout</span>
        </button>
      </div>
    </nav>
  );
}