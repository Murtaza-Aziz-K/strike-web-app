import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import AiChat from './components/AiChat';
import RevenueTracker from './components/RevenueTracker';
import QuoteGenerator from './components/QuoteGenerator';
import UsageDashboard from './components/UsageDashboard';
import Settings from './components/Settings';
import DashboardLayout from './components/DashboardLayout';
import useAuthStore from './store/authStore';

function App() {
  const { isAuthenticated, user } = useAuthStore();

  return (
    <Router>
      <Routes>
        <Route 
          path="/login" 
          element={isAuthenticated ? <Navigate to="/dashboard" /> : <LoginPage />} 
        />
        <Route 
          path="/dashboard" 
          element={
            isAuthenticated ? (
              <DashboardLayout>
                <Dashboard />
              </DashboardLayout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/ai" 
          element={
            isAuthenticated ? (
              <DashboardLayout>
                <AiChat />
              </DashboardLayout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/revenue" 
          element={
            isAuthenticated ? (
              <DashboardLayout>
                <RevenueTracker />
              </DashboardLayout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/quotes" 
          element={
            isAuthenticated ? (
              <DashboardLayout>
                <QuoteGenerator />
              </DashboardLayout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/usage" 
          element={
            isAuthenticated ? (
              <DashboardLayout>
                <UsageDashboard />
              </DashboardLayout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/settings" 
          element={
            isAuthenticated && user?.role === 'admin' ? (
              <DashboardLayout>
                <Settings />
              </DashboardLayout>
            ) : (
              <Navigate to="/dashboard" />
            )
          } 
        />
        <Route 
          path="*" 
          element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} />} 
        />
      </Routes>
    </Router>
  );
}

export default App;