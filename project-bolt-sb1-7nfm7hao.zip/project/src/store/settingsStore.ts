import { create } from 'zustand';

export interface Activity {
  id: string;
  name: string;
  price: number;
}

interface SettingsState {
  activities: Activity[];
  addActivity: (activity: Omit<Activity, 'id'>) => void;
  updateActivity: (id: string, activity: Partial<Activity>) => void;
  deleteActivity: (id: string) => void;
}

const useSettingsStore = create<SettingsState>((set) => ({
  activities: [
    { id: '1', name: 'Site Survey', price: 250 },
    { id: '2', name: 'Installation', price: 500 },
    { id: '3', name: 'Maintenance', price: 150 },
  ],
  addActivity: (activity) => 
    set((state) => ({
      activities: [...state.activities, { ...activity, id: Date.now().toString() }]
    })),
  updateActivity: (id, activity) =>
    set((state) => ({
      activities: state.activities.map((a) => 
        a.id === id ? { ...a, ...activity } : a
      )
    })),
  deleteActivity: (id) =>
    set((state) => ({
      activities: state.activities.filter((a) => a.id !== id)
    })),
}));

export default useSettingsStore