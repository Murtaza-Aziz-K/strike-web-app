import { create } from 'zustand';

export interface Lead {
  id: string;
  department: string;
  contactName: string;
  company: string;
  value: number;
  status: 'new' | 'contacted' | 'qualified' | 'proposal' | 'closed';
  createdAt: Date;
}

interface RevenueState {
  leads: Lead[];
  addLead: (lead: Omit<Lead, 'id' | 'createdAt'>) => void;
  updateLead: (id: string, lead: Partial<Lead>) => void;
  deleteLead: (id: string) => void;
}

const useRevenueStore = create<RevenueState>((set) => ({
  leads: [
    {
      id: '1',
      department: 'FMCG',
      contactName: 'John Smith',
      company: 'ABC Foods',
      value: 25000,
      status: 'qualified',
      createdAt: new Date('2024-03-01'),
    },
    {
      id: '2',
      department: 'C&I',
      contactName: 'Sarah Johnson',
      company: 'XYZ Industries',
      value: 50000,
      status: 'proposal',
      createdAt: new Date('2024-03-05'),
    },
  ],
  addLead: (lead) =>
    set((state) => ({
      leads: [
        ...state.leads,
        { ...lead, id: Date.now().toString(), createdAt: new Date() },
      ],
    })),
  updateLead: (id, lead) =>
    set((state) => ({
      leads: state.leads.map((l) => (l.id === id ? { ...l, ...lead } : l)),
    })),
  deleteLead: (id) =>
    set((state) => ({
      leads: state.leads.filter((l) => l.id !== id),
    })),
}));

export default useRevenueStore