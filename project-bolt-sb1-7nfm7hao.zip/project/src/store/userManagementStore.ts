import { create } from 'zustand';

export interface Permission {
  dashboard: boolean;
  ai: boolean;
  revenue: boolean;
  quotes: boolean;
  usage: boolean;
  settings: boolean;
}

export interface Role {
  id: string;
  name: string;
  permissions: Permission;
}

export interface User {
  id: string;
  username: string;
  password: string;
  role: string;
  departments: string[];
}

interface UserManagementState {
  users: User[];
  roles: Role[];
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (id: string, user: Partial<Omit<User, 'id' | 'password'>>) => void;
  deleteUser: (id: string) => void;
  addRole: (role: Omit<Role, 'id'>) => void;
  updateRole: (id: string, role: Partial<Role>) => void;
  deleteRole: (id: string) => void;
}

const defaultPermissions: Permission = {
  dashboard: true,
  ai: true,
  revenue: true,
  quotes: true,
  usage: true,
  settings: false,
};

const useUserManagementStore = create<UserManagementState>((set) => ({
  users: [
    {
      id: '1',
      username: 'admin',
      password: 'admin',
      role: 'admin',
      departments: ['FMCG', 'C&I', 'VRP', 'Extravert', 'DIY'],
    },
  ],
  roles: [
    {
      id: 'admin',
      name: 'Administrator',
      permissions: {
        ...defaultPermissions,
        settings: true,
      },
    },
    {
      id: 'user',
      name: 'Standard User',
      permissions: defaultPermissions,
    },
  ],
  addUser: (user) =>
    set((state) => ({
      users: [...state.users, { ...user, id: Date.now().toString() }],
    })),
  updateUser: (id, user) =>
    set((state) => ({
      users: state.users.map((u) =>
        u.id === id ? { ...u, ...user } : u
      ),
    })),
  deleteUser: (id) =>
    set((state) => ({
      users: state.users.filter((u) => u.id !== id),
    })),
  addRole: (role) =>
    set((state) => ({
      roles: [...state.roles, { ...role, id: Date.now().toString() }],
    })),
  updateRole: (id, role) =>
    set((state) => ({
      roles: state.roles.map((r) =>
        r.id === id ? { ...r, ...role } : r
      ),
    })),
  deleteRole: (id) =>
    set((state) => ({
      roles: state.roles.filter((r) => r.id !== id),
      users: state.users.map((u) =>
        u.role === id ? { ...u, role: 'user' } : u
      ),
    })),
}));

export default useUserManagementStore;