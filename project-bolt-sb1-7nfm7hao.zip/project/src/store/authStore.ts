import { create } from 'zustand';
import { AuthState } from '../types/auth';

const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  login: async (username: string, password: string) => {
    // In production, this should make an API call
    if (username === 'admin' && password === 'admin') {
      set({
        user: {
          id: '1',
          username: 'admin',
          role: 'admin'
        },
        isAuthenticated: true
      });
    } else {
      throw new Error('Invalid credentials');
    }
  },
  logout: () => {
    set({ user: null, isAuthenticated: false });
  }
}));

export default useAuthStore;